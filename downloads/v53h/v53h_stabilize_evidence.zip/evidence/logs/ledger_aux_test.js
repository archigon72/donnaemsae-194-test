// 가상 원장 node 회귀: 같은 앱(194-test 메인, 무변경) + v5.3f md vs v53h 자동화 aux md. 실제 원장 미사용. GrokBot 자체 검증
const fs=require('fs');const ROOT='/workspace/r194';
function load(){for(const k of Object.keys(require.cache))delete require.cache[k];delete globalThis.ManagementLedger;delete globalThis.ManagementData;
 const L=require(ROOT+'/management-ledger.js');globalThis.ManagementLedger=L;const MD=require(ROOT+'/management-data.js');return {L,MD:MD||globalThis.ManagementData}}
const AID='virt-a',AID2='virt-b',asOf='2026-10-13';
const state={schema_version:1,created_at:'2026-10-14T00:00:00.000Z',accounts:[{account_id:AID,name:'가상-일반',type:'일반'},{account_id:AID2,name:'가상-ISA',type:'ISA'}],
 dividend_confirmations:[{account_id:AID,distribution_id:'0048J0-20260929',amount:'21551',confirmed_at:'2026-10-14T00:00:00.000Z'}],
 transactions:[{transaction_id:'t1',account_id:AID,code:'329200',cycle_id:'c1',type:'initial_buy',trade_date:'2024-05-02',order_key:0,quantity:'100',trade_price:'5000'},
  {transaction_id:'t2',account_id:AID,code:'0048J0',cycle_id:'c2',type:'initial_buy',trade_date:'2026-05-01',order_key:0,quantity:'500',trade_price:'13500'},
  {transaction_id:'t3',account_id:AID2,code:'484880',cycle_id:'c3',type:'initial_buy',trade_date:'2024-07-01',order_key:0,quantity:'10',trade_price:'10000'},
  {transaction_id:'t4',account_id:AID2,code:'0004G0',cycle_id:'c4',type:'initial_buy',trade_date:'2025-02-03',order_key:0,quantity:'20',trade_price:'10000'}],
 dividend_uses:[{use_id:'u1',account_id:AID,use_date:'2026-10-10',order_key:0,amount:'20000'}],metadata:{app:'donnaemsae-lab',scope:'user-facts'}};
const snap=JSON.stringify(state);const out={};
for(const [tag,p] of [['v53f',ROOT+'/data/management-distributions.json'],['aux','/workspace/lt3/live/auto-test/releases/auto-20261014-192337-live/aux/management-distributions.json']]){
 const {L,MD}=load();const md=JSON.parse(fs.readFileSync(p));const r=L.replay(JSON.parse(snap),md.items,asOf);
 out[tag]={md,dv:r.events.filter(e=>e.kind==='dividend').map(e=>({id:e.distribution_id,acc:e.account_id,date:e.date,amt:e.amount.str(2),kind:e.pay_date_kind||null})),issues:r.issues,sp:MD.split(md.items)}}
const v=out.v53f,a=out.aux,R=[];const chk=(n,ok,d)=>{R.push({check:n,pass:!!ok,detail:d});console.log((ok?'PASS ':'FAIL ')+n,JSON.stringify(d??'').slice(0,240))};
chk('입력 원장 객체 불변',JSON.stringify(state)===snap);
const key=e=>e.id+'|'+e.acc;const vm=new Map(v.dv.map(e=>[key(e),e])),am=new Map(a.dv.map(e=>[key(e),e]));
const added=new Set(a.md.items.filter(x=>x.oneclick_added).map(x=>x.distribution_id));
chk('v5.3f 이벤트 소실 0 (예상금액 누락 0)',[...vm.keys()].every(k=>am.has(k)),[...vm.keys()].filter(k=>!am.has(k)));
chk('추가 이벤트는 신규 회차(oneclick_added)만',[...am.keys()].filter(k=>!vm.has(k)).every(k=>added.has(k.split('|')[0])),[...am.keys()].filter(k=>!vm.has(k)));
chk('자동배당 이벤트 중복 0 (실입금 중복 0)',new Set(a.dv.map(key)).size===a.dv.length);
chk('공통 이벤트 금액·날짜·kind 동일',[...vm.keys()].every(k=>am.get(k).amt===vm.get(k).amt&&am.get(k).date===vm.get(k).date&&am.get(k).kind===vm.get(k).kind));
const s=a.dv.filter(e=>e.id.startsWith('329200-202406'));chk('329200 2024-06 회차 1건 41원×100=4,100 지급 2024-07-02',s.length===1&&Number(s[0].amt)===4100&&s[0].date==='2024-07-02',s);
const c48=a.dv.filter(e=>e.id==='0048J0-20260929');chk('0048J0 9/29 실입금 확정 1건만 반영',c48.length===1,c48);
chk('payable 행 = v5.3f + 신규(cashflow_included)',a.sp.payable.length===v.sp.payable.length+[...added].length,[v.sp.payable.length,a.sp.payable.length,added.size]);
chk('replay issues 동일',JSON.stringify(a.issues)===JSON.stringify(v.issues),[v.issues.length,a.issues.length]);
fs.writeFileSync('/workspace/v53h/ledger_aux_test.json',JSON.stringify(R,null,1));console.log('SUMMARY',R.filter(x=>x.pass).length+'/'+R.length);
