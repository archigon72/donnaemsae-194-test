# 백업·복원 검증 (GrokBot 자체 검증, 2026-10-14T10:32:03Z)
| 백업 | 파일 수 | 무결성(unzip -t) | 임시 복원 후 해시 비교 |
|---|---|---|---|
| baseline_617a6b3_scope.zip (작업 전 기준, 범위: .github/oneclick, workflow yml, auto-test) | 2103 | OK | git 617a6b3 과 2103/2103 일치 |
| workcopy_inprogress_scope.zip (작업 중 사본, 2026-10-14 10:2x UTC) | 2105 | OK | 당시 작업 트리와 2105/2105 일치 |
| completed_e071f33_scope.zip (완성본) | 2105 | OK | git e071f33 과 일치 |
복원: 원하는 ZIP 을 저장소 루트에 풀어 덮어쓴 뒤 커밋(강제 push 불필요). 또는 git checkout <617a6b3|e071f33> -- .github/oneclick auto-test/index.html
