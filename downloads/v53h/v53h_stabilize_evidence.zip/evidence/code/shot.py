import asyncio,json
from playwright.async_api import async_playwright
CHK="""()=>{const de=document.documentElement;const els=[...document.querySelectorAll('h1,h2,p,.row .k,.row .v,.badge,code')].filter(e=>e.getClientRects().length);
let ov=[];for(const e of document.querySelectorAll('body *')){const r=e.getBoundingClientRect();if(r.right>innerWidth+0.5||r.left<-0.5)ov.push(e.tagName+'.'+e.className)}
let lap=[];const rs=els.flatMap(e=>[...e.getClientRects()].map(r=>[e,r]));
for(let i=0;i<rs.length;i++)for(let j=i+1;j<rs.length;j++){const[a,A]=rs[i],[b,B]=rs[j];if(a===b||a.contains(b)||b.contains(a))continue;
 const x=Math.min(A.right,B.right)-Math.max(A.left,B.left),y=Math.min(A.bottom,B.bottom)-Math.max(A.top,B.top);if(x>1&&y>1)lap.push([a.textContent.slice(0,20),b.textContent.slice(0,20)])}
return {w:innerWidth,scrollW:de.scrollWidth,clientW:de.clientWidth,h_overflow:de.scrollWidth>de.clientWidth,overflow_elems:ov.slice(0,5),overlap:lap.slice(0,5),cards:document.querySelectorAll('.card').length,h1_lines:Math.round(document.querySelector('h1').getBoundingClientRect().height/ (parseFloat(getComputedStyle(document.querySelector('h1')).lineHeight)||24)),latest_text:document.getElementById('latest').innerText.slice(0,400)}}"""
async def main():
    R={}
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        for w in (360,390,430):
            pg=await b.new_page(viewport={'width':w,'height':800},device_scale_factor=2,is_mobile=True,has_touch=True)
            await pg.goto('http://127.0.0.1:8795/auto-test/',wait_until='networkidle');await pg.wait_for_timeout(800)
            R[w]=await pg.evaluate(CHK);await pg.screenshot(path=f'/workspace/v53h/shots/autotest_{w}px.png',full_page=True)
            await pg.screenshot(path=f'/workspace/v53h/shots/autotest_{w}px_top.png')
        await b.close()
    json.dump(R,open('/workspace/v53h/shots/mobile_check.json','w'),ensure_ascii=False,indent=1)
    for w,r in R.items(): print(w,{k:r[k] for k in ('scrollW','clientW','h_overflow','overflow_elems','overlap','cards','h1_lines')})
asyncio.run(main())
