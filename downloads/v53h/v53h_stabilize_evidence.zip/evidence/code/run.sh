n=$1; sc=$2; mode=$3; shift 3
rm -rf /workspace/lt3/$n; cp -a /workspace/r194 /workspace/lt3/$n; rm -rf /workspace/lt3/$n/.git
sed -i "s/\"scenario\":\"none\"/\"scenario\":\"$sc\"/" /workspace/lt3/$n/.github/oneclick/test_control.json
cd /workspace/lt3/$n; [ "$n" = nostore ] && rm auto-test/meta/product_meta_store.json
pre=$( (sha256sum auto-test/latest.json; find auto-test/releases -type f | sort | xargs sha256sum) | sha256sum | cut -c1-16)
X="--mode replay --replay-dir /workspace/lt3/replay"; [ "$mode" = live ] && X="--mode live"
PYTHONPATH=/workspace/v53g/zeroin_guard ZG_LOG=/workspace/lt3/$n.zg GITHUB_STEP_SUMMARY=/workspace/lt3/$n.sum timeout 2400 python3 .github/oneclick/oneclick.py --site . --raw-dir /workspace/lt3/raw_$n --publish-raw $X "$@" > /workspace/lt3/$n.log 2>&1
ec=$?
post=$( (sha256sum auto-test/latest.json; find auto-test/releases -type f | sort | xargs sha256sum) | sha256sum | cut -c1-16)
prevrel=$(find auto-test/releases/auto-20261014-181446-live -type f | sort | xargs sha256sum | sha256sum | cut -c1-16)
R=$(grep ^RESULT /workspace/lt3/$n.log | awk '{print $2}')
case "$R" in PASS_PROMOTED) y=0;; PASS_PROMOTED_WITH_REUSE) y=0w;; *) y=1;; esac
echo "$n | RESULT=$R | py_exit=$ec | yml_exit=$y | latest+releases pre=$pre post=$post same=$([ $pre = $post ] && echo Y || echo N) | prev_release_hash=$prevrel | zeroin_attempts=$( [ -f /workspace/lt3/$n.zg ] && wc -l < /workspace/lt3/$n.zg || echo 0)"
