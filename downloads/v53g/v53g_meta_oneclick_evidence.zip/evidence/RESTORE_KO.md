# 복원 방법 (GrokBot 자체 검증)
## 1) 코드(.github/oneclick, auto-test/index.html) 되돌리기
- 직전 상태(35f3372, ZeroIn quote 재사용판): backup/backup_35f3372/ 의 oneclick.py, test_control.json, index.html 을 원래 위치에 덮어 커밋
- 최초 원클릭판(e1bc426): backup/backup_e1bc426/oneclick/*, index.html
- 또는 git: `git checkout 35f3372 -- .github/oneclick/oneclick.py .github/oneclick/test_control.json auto-test/index.html` 후 커밋(강제 push 불필요)
- 새로 추가된 funetf_meta.py, build_meta_store.py, auto-test/meta/ 는 일일 경로가 아니라 남겨도 무해. 지우려면 git rm 후 커밋.
## 2) 격리본(latest) 되돌리기
- auto-test/latest.json 을 이전 release(예: auto-20261014-152635-live)를 가리키던 내용으로 되돌리는 커밋. releases/ 는 불변이라 그대로 존재.
## 3) yml 패치 되돌리기(대표가 적용했을 경우)
- backup/backup_35f3372/oneclick-autotest.yml.current 내용으로 .github/workflows/oneclick-autotest.yml 을 다시 붙여넣기(모바일 웹 편집)
## 4) 메인 사이트
- 이번 작업은 메인 사이트(*.html, data/, inputs/, app js) 미변경 → 복원 불필요.
