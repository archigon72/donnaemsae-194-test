# 시험용: ZeroIn 호스트 연결 차단 + 시도 횟수 기록 (네트워크 차단 상태 재현)
import socket,os
_orig=socket.getaddrinfo
def g(host,*a,**k):
    if host and 'zeroin' in str(host):
        open(os.environ.get('ZG_LOG','/tmp/zg.log'),'a').write(str(host)+'\n');raise socket.gaierror('blocked by test guard: '+str(host))
    return _orig(host,*a,**k)
socket.getaddrinfo=g
