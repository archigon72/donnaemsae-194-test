# 실행 명령 (GrokBot 상자)
1. FunETF 메타 수집(1회, 순차·간격 2.5s·429 백오프 30/60/120s·최대 3회): `python3 .github/oneclick/funetf_meta.py --site . --out fmeta/run1`  → logs/funetf_meta_collect*.{txt,json}
2. 저장소 생성: `python3 .github/oneclick/build_meta_store.py --site . --raw fmeta/run1 --out fmeta/store` → tables/*
3. 로컬 원클릭(사본 트리, ZeroIn 차단 가드 PYTHONPATH=code/zeroin_guard_sitecustomize.py):
   - det1/det2: replay, scenario none (결정성)
   - live: 실제 FunETF 네트워크, ZeroIn 차단 → logs/live.log, live.sum
   - loss: test_control scenario=meta_loss (0000D0 issuer·fee 공란 주입)
   - nostore: 메타 저장소 삭제 → WITH_REUSE
   - old: e1bc426 원본 oneclick.py 로 replay → 산출 비교
4. 원장/세금 회귀(메인 앱 무변경 트리, 가상 원장): qa_regress_v53f.py, ledger_guard.py → logs/regress.log, ledger_guard.log
5. yml 패치 검증: PyYAML 파싱 OK, case 분기 exit 코드 시험(PASS_PROMOTED 0 / WITH_REUSE 0+warning / BLOCKED·FAIL·빈값 1)
