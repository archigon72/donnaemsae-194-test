#!/bin/sh
set -e
cat donnaemsae-194-test_v5.2fix_c7d938d.zip.part* > donnaemsae-194-test_v5.2fix_c7d938d.zip
sha256sum -c FULL_ZIP_SHA256.txt
python3 -m zipfile -t donnaemsae-194-test_v5.2fix_c7d938d.zip
python3 -m zipfile -e donnaemsae-194-test_v5.2fix_c7d938d.zip .
cd donnaemsae-194-test_v5.2fix_c7d938d && sha256sum --quiet -c ../FILES_SHA256.txt && echo "ALL $(wc -l < ../FILES_SHA256.txt) FILES OK"
