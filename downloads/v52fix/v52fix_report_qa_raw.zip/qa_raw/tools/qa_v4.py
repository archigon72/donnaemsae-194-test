import asyncio,json,sys,os,time,re
from playwright.async_api import async_playwright
BASE=sys.argv[1];OUT=sys.argv[2];TAG=sys.argv[3];os.makedirs(OUT,exist_ok=True)
LAYOUT=open('/workspace/mobileui/tools/layout.js').read()
R={'base':BASE,'checks':[],'errors':[],'entries':{},'numbers':{}}
def check(n,ok,d=None):
    R['checks'].append({'check':n,'pass':bool(ok),'detail':d});print(('PASS ' if ok else 'FAIL ')+n,json.dumps(d,ensure_ascii=False)[:400] if d is not None else '',flush=True)
F='#trade-form '
async def trade(pg,code,typ,date,qty,price,account=None,new_account=None):
    await pg.goto(BASE+'management.html?mode=ledger',wait_until='networkidle');await pg.wait_for_timeout(400);await pg.click('.mu-fab');await pg.wait_for_timeout(200)
    if new_account: await pg.select_option(F+'select[name=account]','new');await pg.fill(F+'input[name=new_account]',new_account)
    elif account: await pg.select_option(F+'select[name=account]',label=account)
    await pg.fill(F+'input[name=date]',date);await pg.dispatch_event(F+'input[name=date]','change')
    await pg.click(F+f'[data-type-btn={typ}]');await pg.wait_for_timeout(80);await pg.select_option(F+'select[name=code]',code);await pg.dispatch_event(F+'select[name=code]','change')
    if typ=='reinvest':
        await pg.click('#apply-ref-price');await pg.wait_for_timeout(80);await pg.click('#confirm-reinvest');await pg.wait_for_timeout(80)
    else:
        await pg.fill(F+'input[name=quantity]',qty);await pg.fill(F+'input[name=price]',price)
    await pg.click(F+'button[type=submit]');await pg.wait_for_timeout(500)
    e=[x for x in await pg.locator(F+'.form-error').all_inner_texts() if x.strip()] if await pg.locator('#ledger-dialog[open] #trade-form').count() else []
    if e: await pg.keyboard.press('Escape')
    return e
async def comp(pg,tab='instrument',all_=True):
    await pg.goto(BASE+'management.html?mode=composition',wait_until='networkidle');await pg.wait_for_timeout(600)
    await pg.click(f'[data-comp={tab}]');await pg.wait_for_timeout(200)
    if all_ and await pg.locator('[data-action=comp-all]').count() and '전체' in await pg.inner_text('[data-action=comp-all]'):await pg.click('[data-action=comp-all]');await pg.wait_for_timeout(200)
    return await pg.evaluate("""(()=>{const t=document.querySelector('.mu-comp-amt')?.textContent;const rows=[...document.querySelectorAll('.mu-comp-row')].map(r=>({key:r.dataset.key,name:r.querySelector('.mu-comp-name b').textContent,cost:r.dataset.cost,val:r.querySelector('.mu-comp-val b').textContent,pct:r.querySelector('.mu-comp-val small').textContent}));return {total:t,ref:document.querySelector('.mu-comp-ref b')?.textContent,rows,empty:!!document.querySelector('.mu-empty'),arcs:document.querySelectorAll('.mu-donut circle[stroke-dasharray]').length,center:document.querySelector('.mu-donut-c b')?.textContent}})()""")
w2=lambda s:float(s.replace(',','').replace('원','').strip())
def verify(name,c,exp_total,exp_rows):
    tot=w2(c['total']);rs={r['key']:float(r['cost']) for r in c['rows']};psum=sum(float(r['pct'].rstrip('%')) for r in c['rows'])
    ok=abs(tot-exp_total)<0.01 and all(abs(rs.get(k,-1)-v)<0.01 for k,v in exp_rows.items()) and abs(sum(rs.values())-tot)<0.01 and (tot==0 or abs(psum-100)<=0.3)
    # pct numerator/denominator recompute
    pc=all(abs(float(r['pct'].rstrip('%'))-round(float(r['cost'])/tot*100,1))<0.051 for r in c['rows']) if tot else True
    check(name,ok and pc,{'total':c['total'],'rows':[(r['key'][:8],r['val'],r['pct']) for r in c['rows']],'pct_sum':round(psum,1),'expected_total':exp_total})
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    ctx=await b.new_context(viewport={'width':390,'height':844},device_scale_factor=2,is_mobile=True,has_touch=True,locale='ko-KR',timezone_id='Asia/Seoul')
    pg=await ctx.new_page()
    pg.on('console',lambda m:R['errors'].append(['console',m.text,m.location.get('url')]) if m.type=='error' else None)
    pg.on('pageerror',lambda x:R['errors'].append(['pageerror',str(x)]))
    pg.on('requestfailed',lambda r:R['errors'].append(['requestfailed',r.url]) if not r.url.startswith('blob:') else None)
    c=await comp(pg);check('빈 상태: 0원 + 안내',c['empty'] and w2(c['total'])==0,c)
    await pg.screenshot(path=f'{OUT}/{TAG}_390_comp_empty.png',full_page=True)
    t=[]
    t.append(await trade(pg,'497880','initial_buy','2025-12-01','10','50000',new_account='가상-일반'))
    t.append(await trade(pg,'0018C0','initial_buy','2026-03-03','27','13000',account='가상-일반 (일반)'))
    t.append(await trade(pg,'497880','add_buy','2026-03-03','5','50010',account='가상-일반 (일반)'))
    t.append(await trade(pg,'472150','initial_buy','2026-05-20','10','25000',new_account='가상-ISA'))
    check('가상 거래 4건 등록',not any(t),t)
    # entries
    urls={}
    for key,sel,marker in [('A 배당이 키운 자산','.mu-stat.mu-grown','.mc-m-hero'),('B 내가 넣은 돈','.mu-stat.mu-cost','.mu-comp-hero'),('C 배당 성과 분석','.mu-next-perf','.mu-divchart'),('D 계좌·거래 관리','.mu-next-ledger','.mu-acc')]:
        await pg.goto(BASE+'asset-hub.html',wait_until='networkidle');await pg.wait_for_timeout(600)
        await pg.click(sel);await pg.wait_for_load_state('networkidle');await pg.wait_for_timeout(700)
        info={'url':pg.url.replace(BASE,''),'title':await pg.title(),'h1':await pg.inner_text('.mu-banner h1'),'unique':marker,'unique_present':await pg.locator(marker).count()>0,'others_present':[m for m in ('.mc-m-hero','.mu-comp-hero','.mu-divchart','.mu-acc') if m!=marker and await pg.locator(m).count()]}
        R['entries'][key]=info;urls[key]=info['url']
        await pg.screenshot(path=f'{OUT}/{TAG}_390_entry_{key[0]}.png',full_page=True)
        check(f'홈 진입 {key}: 고유 콘텐츠 있음, 다른 화면 콘텐츠 없음',info['unique_present'] and not info['others_present'],info)
    check('A/B/C/D 주소와 제목 모두 다름',len(set(urls.values()))==4 and len({R['entries'][k]['title'] for k in R['entries']})==4,urls)
    # numeric example 1
    c=await comp(pg,'instrument');R['numbers']['inst1']=c
    verify('예시1 종목별: 497880 750,050 / 0018C0 351,000 / 472150 250,000 / 합계 1,351,050',c,1351050,{'497880':750050,'0018C0':351000,'472150':250000})
    await pg.goto(BASE+'asset-hub.html',wait_until='networkidle');await pg.wait_for_timeout(500);home=await pg.inner_text('.mu-stat.mu-cost b')
    check('홈 "내가 넣은 돈" = 구성 화면 대표금액',w2(home)==w2(c['total']),[home,c['total']])
    c=await comp(pg,'account');ids={r['name']:float(r['cost']) for r in c['rows']}
    check('예시2 계좌별: 일반 1,101,050 / ISA 250,000',ids.get('가상-일반')==1101050 and ids.get('가상-ISA')==250000 and abs(sum(ids.values())-w2(c['total']))<0.01,c['rows'])
    # sell
    e=await trade(pg,'497880','sell','2026-07-01','3','50030',account='가상-일반 (일반)');c=await comp(pg,'instrument')
    verify('매도 3주 반영: 497880 750,050×12/15=600,040, 합계 1,201,040',c,1201040,{'497880':600040,'0018C0':351000,'472150':250000})
    # reinvest new ETF (0005A0) - direct total unchanged, ref line >0
    e=await trade(pg,'0005A0','reinvest','2026-10-07',None,None,account='가상-일반 (일반)');c=await comp(pg,'instrument')
    check('신규 ETF 재투자: 대표금액 불변, 재투자 참고줄 증가, 0005A0 0원',not e and w2(c['total'])==1201040 and w2(c['ref'])>0 and any(r['key']=='0005A0' and float(r['cost'])==0 for r in c['rows']),{'err':e,'total':c['total'],'ref':c['ref']})
    # full sell 0018C0 and ISA
    e1=await trade(pg,'0018C0','sell','2026-09-01','27','13200',account='가상-일반 (일반)');e2=await trade(pg,'472150','sell','2026-10-08','10','20000',account='가상-ISA (일반)')
    c=await comp(pg,'instrument');check('전량매도 반영: 0018C0·472150 목록에서 사라짐, 합계 600,040',not e1 and not e2 and w2(c['total'])==600040 and not any(r['key'] in('0018C0','472150') for r in c['rows']),{'e':[e1,e2],'rows':c['rows']})
    c=await comp(pg,'account');ids={r['name']:r['val'] for r in c['rows']}
    check('계좌 전환: ISA 0원 계좌 표시, 일반 600,040',ids.get('가상-ISA')=='0원' and w2(ids.get('가상-일반','0'))==600040,ids)
    # reload persistence (tab kept)
    await pg.reload(wait_until='networkidle');await pg.wait_for_timeout(700)
    tab=await pg.get_attribute('[data-comp=account]','aria-pressed');tot=await pg.inner_text('.mu-comp-amt')
    check('새로고침 후 탭·값 유지',tab=='true' and w2(tot)==600040,[tab,tot])
    # >5 items, 기타, 전체보기, long names
    cat=await pg.evaluate("fetch('data/catalog.json').then(r=>r.json()).then(d=>d.items.map(x=>[x.ticker,x.name]))")
    longest=sorted(cat,key=lambda x:-len(x[1]))[:6]
    for i,(code,nm) in enumerate(longest):
        await trade(pg,code,'initial_buy','2026-10-0'+str(1+i%5),'1',str(10000+i*1000),account='가상-일반 (일반)')
    c=await comp(pg,'instrument',all_=False)
    more=await pg.locator('[data-action=comp-all]').count();shown=len(c['rows']);arcs=c['arcs']
    check('6개 이상: 상위 5개 표시, 전체 보기 버튼, 도넛 6조각(상위5+기타)',shown==5 and more==1 and arcs==6,{'shown':shown,'arcs':arcs,'names':[r['name'] for r in c['rows']]})
    c=await comp(pg,'instrument',all_=True);check('전체 보기: 모든 항목 확인 가능, 기타 표기',len(c['rows'])>=8 and len([r for r in c['rows'] if float(r['cost'])>0])>=7,len(c['rows']))
    verify('예시3 다종목 합계·비중 일치',c,w2(c['total']),{})
    # 10억+
    await trade(pg,'497880','add_buy','2026-10-08','20000','50000',account='가상-일반 (일반)')
    c=await comp(pg,'instrument',all_=True);check('10억 이상 금액 표시',w2(c['total'])>=1e9,c['total'])
    lay={}
    for w in (360,390,412,430):
        await pg.set_viewport_size({'width':w,'height':844})
        for tab in ('instrument','account'):
            await comp(pg,tab,all_=True);h=await pg.evaluate('document.documentElement.scrollHeight');await pg.set_viewport_size({'width':w,'height':h});r=await pg.evaluate(LAYOUT)
            await pg.screenshot(path=f'{OUT}/{TAG}_{w}_comp_{tab}_long.png');await pg.set_viewport_size({'width':w,'height':844})
            iss={k:v for k,v in r.items() if k in('over','esc','clip','deco','small') and v}
            lay[f'{w}_{tab}']=iss
        await pg.goto(BASE+'management.html?mode=dividends',wait_until='networkidle');await pg.wait_for_timeout(500);await pg.click('[data-scope=all]');await pg.wait_for_timeout(300)
        h=await pg.evaluate('document.documentElement.scrollHeight');await pg.set_viewport_size({'width':w,'height':h});r=await pg.evaluate(LAYOUT);await pg.screenshot(path=f'{OUT}/{TAG}_{w}_dividends_long.png');await pg.set_viewport_size({'width':w,'height':844})
        lay[f'{w}_dividends']={k:v for k,v in r.items() if k in('over','esc','clip','deco','small') and v}
        await pg.goto(BASE+'management.html?mode=performance',wait_until='networkidle');await pg.wait_for_timeout(500)
        h=await pg.evaluate('document.documentElement.scrollHeight');await pg.set_viewport_size({'width':w,'height':h});r=await pg.evaluate(LAYOUT);txt=await pg.inner_text('#app');await pg.screenshot(path=f'{OUT}/{TAG}_{w}_performance_long.png');await pg.set_viewport_size({'width':w,'height':844})
        lay[f'{w}_performance']={k:v for k,v in r.items() if k in('over','esc','clip','deco','small') and v}
    R['layout_edge']=lay
    check('긴 이름·10억·빈 계좌: 360/390/412/430 넘침·이탈·잘림 0',all(not v for v in lay.values()),lay)
    check('월별 차트: "합계" 카드/문구 없음, 새 제목·주의문 있음','합계 (' not in txt and '월별 직접투자 원가와 누적 수령 배당' in txt and '총자산·평가액이 아닙니다' in txt and '사용·재투자분 포함' in txt and '현재 총자산' not in txt)
    await pg.evaluate('localStorage.clear()');check('가상 데이터 정리',await pg.evaluate('localStorage.length')==0)
    check('console/pageerror/requestfailed 0',not R['errors'],R['errors'][:5])
    json.dump(R,open(f'{OUT}/{TAG}_v4qa.json','w'),ensure_ascii=False,indent=1);await b.close()
asyncio.run(main())
