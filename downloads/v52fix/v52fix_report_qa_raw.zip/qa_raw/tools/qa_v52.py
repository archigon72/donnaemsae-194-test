import asyncio,json,sys,os,time,urllib.request
from decimal import Decimal as Dm
exec(open('/workspace/mobileui/tools/qa_v4.py').read().split('async def main')[0])
PAL=['#3B82F6','#2ECC98','#FFC329','#F46D75','#264DA0'];ETC='#6B7280';ZERO='#2b3440'
KEY='donnaemsae.management.facts.v1'
R['requestfailed']=[];R['http_errors']=[];R['snap']={}
GET="""()=>({basis:[...document.querySelectorAll('[data-basis]')].filter(b=>b.tagName==='BUTTON').map(b=>[b.dataset.basis,b.getAttribute('aria-pressed')]),label:document.querySelector('.mu-comp-hero .mu-label')?.textContent,total:document.querySelector('.mu-comp-amt')?.textContent,center:document.querySelector('.mu-donut-c')?.textContent,miss:document.querySelector('.mu-val-miss')?.textContent||'',none:!!document.querySelector('.mu-val-none'),empty:!!document.querySelector('.mu-empty'),basisNote:document.querySelector('.mu-val-basis')?.textContent||'',notes:[...document.querySelectorAll('.mu-comp .record-note')].map(x=>x.textContent),seg:[...document.querySelectorAll('.mu-donut [data-seg]')].map(x=>[x.dataset.seg,x.dataset.color,x.getAttribute('stroke'),x.getAttribute('stroke-dasharray')]),aria:document.querySelector('.mu-donut')?.getAttribute('aria-label'),rows:[...document.querySelectorAll('.mu-comp-row')].map(r=>{const d=r.querySelector('.mu-dot2');return {key:r.dataset.key,amt:r.dataset.cost,miss:r.dataset.missing,color:d.dataset.color,bg:getComputedStyle(d).backgroundColor,name:r.querySelector('.mu-comp-name b').textContent,sub:r.querySelector('.mu-comp-name small').textContent,val:r.querySelector('.mu-comp-val b').textContent,pct:r.querySelector('.mu-comp-val small').textContent}})})"""
HAS_TOGGLE=True
async def view(pg,tab='instrument',basis='cost',all_=True,nav=True):
    if nav: await pg.goto(BASE+'management.html?mode=composition',wait_until='networkidle');await pg.wait_for_timeout(500)
    if basis=='value': await pg.click('button[data-basis=value]');await pg.wait_for_timeout(200)
    await pg.click(f'[data-comp={tab}]');await pg.wait_for_timeout(200)
    if all_ and await pg.locator('[data-action=comp-all]').count() and '전체' in await pg.inner_text('[data-action=comp-all]'):await pg.click('[data-action=comp-all]');await pg.wait_for_timeout(200)
    return await pg.evaluate(GET)
def rgb(h):h=h.lstrip('#');return 'rgb(%d, %d, %d)'%tuple(int(h[i:i+2],16) for i in (0,2,4))
def amt(r): return Dm(r['amt']) if r['amt'] not in ('',None) else None
def colorcheck(tag,c):
    rows=c['rows'];val=[r for r in rows if amt(r) is not None];pos=[r for r in val if amt(r)>0]
    order=all((amt(a)>amt(b)) or (amt(a)==amt(b) and a['key']<b['key']) for a,b in zip(val,val[1:])) and all(amt(r) is None for r in rows[len(val):])
    exp=[(PAL[i] if i<5 else ETC) for i in range(len(pos))]
    dots=[r['color'] for r in pos]==exp and all(r['bg']==rgb(r['color']) for r in rows) and all(r['color']==ZERO for r in rows if r not in pos)
    seg=c['seg'];top=[s for s in seg if s[0]!='__etc'];etc=[s for s in seg if s[0]=='__etc']
    segok=[s[0] for s in top]==[r['key'] for r in pos[:5]] and [s[1] for s in top]==PAL[:len(top)] and all(s[1]==s[2] for s in seg) and all(s[1]==ETC for s in etc) and (bool(etc)==(len(pos)>5))
    check(f'{tag}: 금액 내림차순(동률 ID)·미확인 맨뒤',order,[(r['key'][:10],r['amt']) for r in rows])
    check(f'{tag}: 상위5 순위색 + 기타 #6B7280, 조각=목록 점 일치',dots and segok,{'seg':[s[:2] for s in seg],'dots':[(r['key'][:10],r['color']) for r in rows]})
async def facts(pg):
    t=await pg.evaluate(f"localStorage.getItem('{KEY}')");return json.loads(t) if t else None
def qty(f):
    q={}
    for t in f['transactions']:
        k=(t['account_id'],t['code']);s=-1 if t['type']=='sell' else 1;q[k]=q.get(k,Dm(0))+s*Dm(t['quantity'])
    return {k:v for k,v in q.items() if v>0}
def oracle(f,prices,tab):
    pm={p['code']:p for p in prices['items']};q=qty(f);out={};miss=set()
    def pv(code):
        p=pm.get(code)
        if not p or p.get('price_type')!='close':return None
        try:v=Dm(p['price'])
        except Exception:return None
        return v if v>0 else None
    for (a,c),n in q.items():
        k=a if tab=='account' else c;v=pv(c)
        if v is None: out[k]=None;miss.add(c);continue
        if k in out and out[k] is None:continue
        out[k]=out.get(k,Dm(0))+n*v
    if tab=='account':
        for a in f['accounts']:out.setdefault(a['account_id'],Dm(0))
    return out,miss
def cmp_oracle(tag,c,f,prices,tab):
    exp,miss=oracle(f,prices,tab);got={r['key']:amt(r) for r in c['rows']}
    ok=set(exp)==set(got) and all((exp[k] is None and got[k] is None) or (exp[k] is not None and got[k] is not None and abs(exp[k]-got[k])<Dm('0.01')) for k in exp)
    known=sum(v for v in exp.values() if v is not None);tot=Dm(c['total'].replace(',','').replace('원','')) if c['total'] and c['total'][0].isdigit() else None
    psum=sum(float(r['pct'].rstrip('%')) for r in c['rows'] if r['pct'].endswith('%'))
    check(f'{tag}: 화면 평가액 = 보유수량(직접+재투자)×prices.json 종가 (독립 계산)',ok,{'exp':{k[:12]:(str(v) if v is not None else None) for k,v in exp.items()},'got':{k[:12]:(str(v) if v is not None else None) for k,v in got.items()},'pct_sum':round(psum,1)})
    return exp,miss
def logs(pg):
    pg.on('console',lambda m:R['errors'].append(['console',m.text,pg.url]) if m.type=='error' else None)
    pg.on('pageerror',lambda x:R['errors'].append(['pageerror',str(x)]))
    pg.on('requestfailed',lambda r:R['requestfailed'].append([r.url,str(r.failure)]))
    pg.on('response',lambda r:R['http_errors'].append([r.status,r.url]) if r.status>=400 else None)
async def shots(pg,label,combos,missing_ok=False):
    lay={}
    for w in (360,390,412,430):
        await pg.set_viewport_size({'width':w,'height':844})
        for basis,tab in combos:
            await view(pg,tab,basis,False)
            h=await pg.evaluate('document.documentElement.scrollHeight');await pg.set_viewport_size({'width':w,'height':h});await pg.wait_for_timeout(150)
            r=await pg.evaluate(LAYOUT);nm=f"{OUT}/{TAG}_{label}_{w}_{basis}_{tab}.png";await pg.screenshot(path=nm);await pg.set_viewport_size({'width':w,'height':844})
            lay[f'{label}_{w}_{basis}_{tab}']={k:v for k,v in r.items() if k in('over','esc','clip','deco','small') and v}
    R.setdefault('layout',{}).update(lay)
    check(f'[{label}] 360/390/412/430 넘침·겹침·이탈 0',all(not v for v in lay.values()),{k:v for k,v in lay.items() if v})
async def main():
  global HAS_TOGGLE
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    mk=lambda **k:b.new_context(viewport={'width':390,'height':844},device_scale_factor=2,is_mobile=True,has_touch=True,locale='ko-KR',timezone_id='Asia/Seoul',**k)
    ctx=await mk();pg=await ctx.new_page();logs(pg)
    await pg.goto(BASE+'management.html?mode=composition',wait_until='networkidle');await pg.wait_for_timeout(500)
    check('격리 프로필: 저장 원장 없음',await facts(pg) is None)
    HAS_TOGGLE=await pg.locator('button[data-basis]').count()==2;R['has_toggle']=HAS_TOGGLE
    prices=json.loads(urllib.request.urlopen(BASE+'data/prices.json').read());cat=json.loads(urllib.request.urlopen(BASE+'data/catalog.json').read())['items']
    if HAS_TOGGLE:
        c=await view(pg,'instrument','value',nav=False);R['snap']['zero_value']=c
        check('⑥ 0건: 평가액 모드 빈 상태(0원, 도넛 없음, 오류 없음)',c['empty'] and not c['seg'] and c['total']=='0원',c)
        c=await view(pg,'account','value',nav=False);check('⑥ 0건: 계좌별도 빈 상태',c['empty'] and not c['seg'],c['total'])
    longest=max(cat,key=lambda x:len(x['name']))['ticker'];R['longest']=[longest,max(len(x['name']) for x in cat)]
    T=[('497880','initial_buy','2026-03-02','4','50000',None,'가상-일반'),('0018C0','initial_buy','2026-03-03','10','13000','가상-일반 (일반)',None),
       ('472150','initial_buy','2026-05-20','8','25000',None,'가상-ISA'),('0005A0','initial_buy','2026-05-21','10','10000',None,'가상-연금'),
       (longest,'initial_buy','2026-06-01','20000','10000',None,'가상-억단위 아주 긴 이름의 테스트 계좌')]
    others=[x['ticker'] for x in cat if x['ticker'] not in {t[0] for t in T}][:4]
    T+= [(others[0],'initial_buy','2026-06-02','3','10000',None,'가상-5'),(others[1],'initial_buy','2026-06-03','2','10000',None,'가상-6'),(others[2],'initial_buy','2026-06-04','5','10000',None,'가상-7'),(others[3],'initial_buy','2026-06-05','1','10000','가상-일반 (일반)',None)]
    errs=[]
    for code,typ,d,q,pr,acc,new in T: errs.append(await trade(pg,code,typ,d,q,pr,account=acc,new_account=new))
    check('가상 거래 9건·7계좌 등록',not any(errs),errs)
    f=await facts(pg);R['facts_initial']=f
    # ⑩ cost mode snapshot (also run on baseline)
    for tab in ('instrument','account'):
        R['snap']['cost_'+tab]=await view(pg,tab,'cost')
    R['snap']['cost_default_instrument']=await view(pg,'instrument','cost',False)
    if not HAS_TOGGLE:
        json.dump(R,open(f'{OUT}/{TAG}_qa.json','w'),ensure_ascii=False,indent=1);await b.close();return
    c=await view(pg,'instrument','cost',False)
    check('① 진입 기본값 = 직접투자 원가',c['basis']==[['cost','true'],['value','false']],c['basis'])
    for tab in ('instrument','account'):
        v=await view(pg,tab,'value');R['snap']['value_'+tab]=v
        check(f'① [{tab}] 평가액 전환: 제목/버튼 상태',v['basis']==[['cost','false'],['value','true']] and v['label']=='현재 보유 ETF 평가액 합계',v['label'])
        exp,miss=cmp_oracle(f'②③ [{tab}] 일반',v,f,prices,tab)
        tot=sum(x for x in exp.values() if x is not None);check(f'② [{tab}] 중앙/상단 합계 = 행 합계 = 전체 평가액',v['total']==f"{int(tot):,}원" or v['total'].replace(',','').startswith(str(int(tot))),[v['total'],str(tot),v['center']])
        colorcheck(f'⑨ [평가액 {tab}]',v)
        # back to cost
        await pg.click('button[data-basis=cost]');await pg.wait_for_timeout(200)
        if await pg.locator('[data-action=comp-all]').count() and '전체' in await pg.inner_text('[data-action=comp-all]'):await pg.click('[data-action=comp-all]');await pg.wait_for_timeout(200)
        c2=await pg.evaluate(GET)
        check(f'① [{tab}] 평가액→원가 복귀 시 원가 화면 동일',{k:c2[k] for k in('total','rows','seg')}=={k:R['snap']['cost_'+tab][k] for k in('total','rows','seg')})
    R['value_total_initial']=R['snap']['value_instrument']['total']
    # ④ cash excluded: home total = value total + cash
    await pg.goto(BASE+'asset-home.html',wait_until='networkidle');await pg.wait_for_timeout(700)
    home=await pg.evaluate("({amt:document.querySelector('.mu-amt')?.textContent,cash:document.querySelector('.cash-value b')?.textContent,def:document.querySelector('.mu-def')?.textContent})")
    n=lambda s:Dm(s.replace(',','').replace('원','').replace(' · 확인분','').strip())
    vt=n(R['snap']['value_instrument']['total'])
    check('④ 배당현금 분모 제외: 홈 현재 자산가치 = 평가액 도넛 합계 + 배당현금',n(home['amt'])==vt+n(home['cash']),{'home':home,'donut_total':str(vt)})
    R['home']=home
    # ⑦ buy / sell / reinvest
    e1=await trade(pg,'0018C0','sell','2026-10-07','4','14000',account='가상-일반 (일반)')
    e2=await trade(pg,'472150','add_buy','2026-10-07','30','25000',account='가상-ISA (일반)')
    await openform_reinv(pg)
    e3=R.get('reinv_err')
    f2=await facts(pg);R['facts_after']={'types':[t['type'] for t in f2['transactions']]}
    check('⑦ 매도·추가매수·배당재투자 거래 등록',not e1 and not e2 and not e3 and 'reinvest' in R['facts_after']['types'],[e1,e2,e3])
    for tab in ('instrument','account'):
        v=await view(pg,tab,'value');R['snap']['value_after_'+tab]=v;cmp_oracle(f'⑦③ [{tab}] 거래 후 갱신(재투자 수량 포함)',v,f2,prices,tab);colorcheck(f'⑨ [거래 후 평가액 {tab}]',v)
    rq=[t for t in f2['transactions'] if t['type']=='reinvest'];
    if rq:
        r0=rq[-1];exp_q=qty(f2)[(r0['account_id'],r0['code'])];pm={x['code']:Dm(x['price']) for x in prices['items']}
        row=[r for r in R['snap']['value_after_instrument']['rows'] if r['key']==r0['code']]
        check('③ 재투자 수량 포함: 해당 종목 평가액 = (직접+재투자)×종가',row and abs(Dm(row[0]['amt'])-sum(q*pm[c] for (a,c),q in qty(f2).items() if c==r0['code']))<Dm('0.01'),{'code':r0['code'],'reinvest_qty':r0['quantity'],'row':row[0]['amt'] if row else None})
    # ⑧ reload / tab switching
    v=await view(pg,'account','value');await pg.click('[data-comp=instrument]');await pg.wait_for_timeout(200);a=await pg.evaluate(GET)
    check('⑧ 탭 전환 시 평가액 기준 유지',a['basis'][1]==['value','true'] and a['label']=='현재 보유 ETF 평가액 합계',a['basis'])
    await pg.reload(wait_until='networkidle');await pg.wait_for_timeout(600);a=await pg.evaluate(GET)
    check('⑧ 새로고침 후 기본값(직접투자 원가)으로 진입',a['basis'][0]==['cost','true'],a['basis'])
    v2=await view(pg,'instrument','value',True,False)
    check('⑧ 새로고침 후 평가액 값·색 동일',{k:v2[k] for k in('total','rows','seg')}=={k:R['snap']['value_after_instrument'][k] for k in('total','rows','seg')})
    await shots(pg,'normal',[('cost','instrument'),('cost','account'),('value','instrument'),('value','account')])
    fa=await facts(pg);R['facts_final']=fa
    await ctx.close()
    # ⑤ price scenarios in separate isolated contexts with SW blocked, ledger seeded virtually
    seed=json.dumps(fa)
    miss_code=longest; zero_code='472150'
    def mod(kind):
        P=json.loads(json.dumps(prices))
        if kind=='missing':P['items']=[x for x in P['items'] if x['code']!=miss_code]
        if kind=='zero':
            for x in P['items']:
                if x['code']==zero_code:x['price']='0'
        if kind=='mixed':
            for x in P['items']:
                if x['code']=='0005A0':x['trade_date']='2026-10-07';x['price']=str(Dm(x['price'])-5)
        if kind=='allmissing':P['items']=[]
        return P
    for kind in ('missing','zero','mixed','allmissing','cached','error'):
        cx=await mk(service_workers='block');await cx.add_init_script("if(!localStorage.getItem('%s'))localStorage.setItem('%s',%s)"%(KEY,KEY,json.dumps(seed)))
        state={'n':0}
        def mkh(kind):
          async def h(route):
              state['n']+=1
              if kind=='cached':
                  if state['n']==1:await route.continue_();return
                  await route.abort();return
              if kind=='error':await route.fulfill(status=500,body='err');return
              await route.fulfill(status=200,content_type='application/json',body=json.dumps(mod(kind)))
          return h
        await cx.route('**/data/prices.json',mkh(kind));pg=await cx.new_page();logs(pg)
        if kind=='cached':await pg.goto(BASE+'management.html?mode=composition',wait_until='networkidle');await pg.wait_for_timeout(500)
        P=prices if kind in ('cached',) else ({'items':[]} if kind=='error' else mod(kind))
        for tab in ('instrument','account'):
            v=await view(pg,tab,'value');R['snap'][f'{kind}_{tab}']=v;cmp_oracle(f'⑤ [{kind} {tab}]',v,fa,P,tab)
            if kind in('missing','zero'):
                check(f'⑤ [{kind} {tab}] 일부 미제공 명시·전체 아님 라벨·0원 가장 없음',v['label']=='확인 가능한 종목 평가액 합계(전체 아님)' and '일부 평가액 미제공' in v['miss'] and name_in(v,cat,miss_code if kind=='missing' else zero_code) and '확인 가능한 항목 내 비중' in ' '.join(v['notes']) and any(r['miss']=='1' and r['val']=='평가액 미확인' for r in v['rows']) and '확인분' in (v['center'] or '') and '전체 아님' in (v['aria'] or ''),{'label':v['label'],'miss':v['miss'][:160],'center':v['center']})
                colorcheck(f'⑨ [{kind} {tab}]',v)
            if kind=='mixed':check(f'⑤ [mixed {tab}] 가격 기준일 혼합·이전 종가 안내, 실시간 표현 없음','가격 기준일 혼합' in v['basisNote'] and '이전 종가' in v['basisNote'] and '실시간 가격 아님' in v['basisNote'],v['basisNote'])
            if kind in('allmissing','error'):check(f'⑤ [{kind} {tab}] 전체 결측: 도넛 미표시·평가액 미확인·0원 가장 없음',not v['seg'] and v['none'] and v['total']=='평가액 미확인' and all(r['val']=='평가액 미확인' for r in v['rows'] if r['sub'].find('0원 (보유 없음)')<0),{'total':v['total'],'miss':v['miss'][:120]})
            if kind=='cached':check(f'⑤ [cached {tab}] 이전값(캐시) 안내 + 값 유지','이전값(캐시)' in v['basisNote'] and v['label']=='현재 보유 ETF 평가액 합계',v['basisNote'])
        if kind=='missing':await shots(pg,'missing',[('value','instrument'),('value','account')])
        if kind=='allmissing':await shots(pg,'allmissing',[('value','instrument')])
        await cx.close()
    await b.close()
  R['errors_note']='requestfailed during cached/error scenarios are intentional route aborts'
  check('console/pageerror 0 (의도된 가격 오류 시나리오 콘솔 제외 전 원본 기록 별도)',not [e for e in R['errors'] if e[0]=='pageerror'] and not [e for e in R['errors'] if e[0]=='console' and 'prices.json' not in e[1] and '500' not in e[1] and 'ERR_FAILED' not in e[1]],R['errors'][:8])
  json.dump(R,open(f'{OUT}/{TAG}_qa.json','w'),ensure_ascii=False,indent=1,default=str)
def name_in(v,cat,code):
    n=[x['name'] for x in cat if x['ticker']==code][0];return n in v['miss']
async def openform_reinv(pg):
    await pg.goto(BASE+'management.html?mode=ledger',wait_until='networkidle');await pg.wait_for_timeout(500);await pg.click('.mu-fab');await pg.wait_for_timeout(250)
    await pg.select_option(F+'select[name=account]',label='가상-일반 (일반)');await pg.fill(F+'input[name=date]','2026-10-08');await pg.dispatch_event(F+'input[name=date]','change')
    await pg.click(F+'[data-type-btn=reinvest]');await pg.wait_for_timeout(100);await pg.select_option(F+'select[name=code]','0018C0');await pg.dispatch_event(F+'select[name=code]','change')
    await pg.click('#apply-ref-price');await pg.wait_for_timeout(100);await pg.click('#confirm-reinvest');await pg.wait_for_timeout(100)
    R['reinv']={'qty':await pg.input_value(F+'input[name=quantity]'),'calc':await pg.inner_text('#reinvest-calc')}
    await pg.click(F+'button[type=submit]');await pg.wait_for_timeout(600)
    e=[x for x in await pg.locator(F+'.form-error').all_inner_texts() if x.strip()] if await pg.locator('#ledger-dialog[open] #trade-form').count() else []
    R['reinv_err']=e
asyncio.run(main())
